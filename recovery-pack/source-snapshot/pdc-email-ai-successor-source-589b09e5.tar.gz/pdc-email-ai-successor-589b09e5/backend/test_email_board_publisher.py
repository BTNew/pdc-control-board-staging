import tempfile
import unittest
from pathlib import Path
from unittest import mock

import email_board_publisher as publisher


class EmailBoardPublisherTests(unittest.TestCase):
    def test_structured_parts_updates_are_review_only(self):
        record = {
            "id": "email-1",
            "sender_email": "parts@example.com",
            "received_at": "2026-07-14T01:00:00Z",
            "subject": "Parts update",
            "parsed_text": (
                "Stock: 12666620\nParts: complete\nNotes: Towbar kit arrived\n\n"
                "Stock: 13010530\nParts: stoppage\nReason: Supplier backorder\nETA: 25/07/2026\n"
            ),
        }
        proposals = publisher.parse_parts_review_actions(record)
        self.assertEqual(len(proposals), 2)
        self.assertEqual(proposals[0]["action"], "complete")
        self.assertEqual(proposals[0]["notes"], "Towbar kit arrived")
        self.assertEqual(proposals[1]["action"], "stoppage")
        self.assertEqual(proposals[1]["reason"], "Supplier backorder")
        self.assertEqual(proposals[1]["eta"], "25/07/2026")

    def test_unstructured_email_creates_no_action(self):
        self.assertEqual(publisher.parse_parts_review_actions({"id": "x", "parsed_text": "Please check this job"}), [])

    def test_generated_payload_keeps_reviews_separate(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "email-board-data.js"
            reviews = [{"id": "e:1234:parts:complete", "stock": "1234", "action": "complete"}]
            self.assertTrue(publisher.write_generated(path, [], reviews))
            loaded = publisher.read_existing_generated(path)
            self.assertEqual(loaded["vehicles"], [])
            self.assertEqual(loaded["reviews"], reviews)
            self.assertFalse(publisher.write_generated(path, [], reviews))

    def test_repair_order_labels_do_not_override_vehicle_or_create_pit_work(self):
        record = {"id": "mail-1", "received_at": "2026-07-14T06:45:02Z"}
        attachments = """
CUSTOMER:\n\n67401
VEHICLE:\n\nMONTH/YEAR:
EWN QC Time Required:
VEHICLE:\n\nRAV4 AWD 2.5L Hyb CVT GX (SS) 7460930 001
STOCK No.: 13037843
JOB CARD No.: J139125129
P.O. No. GP10223986
Customer: North Regional Tafe, North Regional Tafe
M1 Tint
Nudge Bar - Black
WIRE PARKING SENSOR EXTENSION
"""
        vehicle = publisher.parse_vehicle_from_text(record, "Order 13037843", "", attachments)
        self.assertIsNotNone(vehicle)
        self.assertEqual(vehicle.vehicle, "RAV4 AWD 2.5L Hyb CVT GX (SS) 7460930 001")
        self.assertEqual(vehicle.client, "North Regional Tafe")
        self.assertEqual(vehicle.purchaseOrderNumber, "GP10223986")
        self.assertFalse(vehicle.pdcRequiresPitInspection)
        self.assertEqual([line["description"] for line in vehicle.pdcJobLines], [
            "M1 Tint", "Nudge Bar - Black", "WIRE PARKING SENSOR EXTENSION",
        ])
        self.assertEqual(vehicle.pdcJobLines[0]["estimatedHours"], 3.0)
        self.assertEqual([line["suggestedStage"] for line in vehicle.pdcJobLines], ["TINT", "FITTING", "ELECTRICAL"])
        self.assertTrue(all(line["estimateStatus"] == "review-required" for line in vehicle.pdcJobLines[1:]))

    def test_generic_email_rows_get_review_only_starting_hours_and_categories(self):
        lines = publisher.extract_job_lines(
            "MISC Hilux 4x4 2.8L Dsl D/C/C 6AT SR 48V 2U24100 001 1 1.00 1.00\n"
            "!ARBGVM ARB Safari Snorkel 1 500.00 500.00\n"
            "!ELEC ARB Slimline Lithium Dual Battery System 1 1000.00 1000.00\n"
            "TEXT BFG KO3 AT Tyre Upgrade x 5",
            {"sourceCode": "DRT20260201.1", "entries": {}, "ambiguous": {}},
        )
        self.assertNotIn("Hilux 4x4 2.8L Dsl D/C/C 6AT SR 48V 2U24100 001", [line["description"] for line in lines])
        snorkel = next(line for line in lines if "Snorkel" in line["description"])
        battery = next(line for line in lines if "Battery" in line["description"])
        tyres = next(line for line in lines if "Tyre" in line["description"])
        self.assertEqual((snorkel["estimatedHours"], snorkel["suggestedStage"]), (3.5, "FITTING"))
        self.assertEqual((battery["estimatedHours"], battery["suggestedStage"]), (6.0, "ELECTRICAL"))
        self.assertEqual((tyres["estimatedHours"], tyres["suggestedStage"]), (2.5, "TYRE"))
        self.assertTrue(all(line["estimateMethod"] == "review-starting-estimate" for line in [snorkel, battery, tyres]))

    def test_vehicle_email_becomes_review_proposal_not_board_vehicle(self):
        vehicle = {
            "stock": "13047064",
            "jobCardNumber": "J123",
            "sourceEmailId": "email-123",
            "pdcJobLines": [{"id": "line-1", "description": "Tray module", "estimatedHours": 12, "suggestedStage": "FABRICATION"}],
        }
        proposal = publisher.vehicle_import_review(vehicle)
        self.assertEqual(proposal["type"], "vehicle-import")
        self.assertEqual(proposal["stock"], "13047064")
        self.assertEqual(proposal["vehicle"]["pdcLocation"], "PMB")
        self.assertEqual(proposal["jobLines"][0]["suggestedStage"], "FABRICATION")
        self.assertNotIn("pdcJobLines", proposal["vehicle"])
        self.assertIsNone(publisher.vehicle_import_review({"stock": "SELLING", "sourceEmailId": "bad"}))
        self.assertIsNone(publisher.vehicle_import_review({"stock": "ABC123", "sourceEmailId": "bad"}))

    def test_arb_catalog_creates_orange_provisional_hours_only_for_unambiguous_code(self):
        catalog = {
            "sourceCode": "DRT20260201.1",
            "labourRate": 160,
            "labourRateSourcePage": 6,
            "entries": {
                "SS177HF": {"hours": 3.5, "page": 100, "fittingCharge": 560, "method": "catalog-fitting-charge-at-160"},
                "SS178HF": {"hours": 3.5, "page": 101, "method": "catalog-fitting-charge-at-160"},
            },
            "ambiguous": {"LX110": [{"hours": 3}, {"hours": 4}]},
        }
        lines = publisher.extract_job_lines(
            "SS177HF Safari snorkel 2 578.85 1157.70\nLX110 LINX interface 1 803.25 803.25",
            catalog,
        )
        self.assertEqual(len(lines), 2)
        snorkel = next(line for line in lines if line["code"] == "SS177HF")
        linx = next(line for line in lines if line["code"] == "LX110")
        self.assertEqual(snorkel["estimatedHours"], 7.0)
        self.assertEqual(snorkel["estimateStatus"], "provisional")
        self.assertIn("page 100", snorkel["estimateSource"])
        self.assertIn("$560 ÷ $160/h", snorkel["estimateSource"])
        self.assertIn("rate p6", snorkel["estimateSource"])
        self.assertIsNone(linx["estimatedHours"])
        self.assertEqual(linx["estimateStatus"], "review-required")
        bundle = publisher.extract_job_lines("SS177HF SS178HF Snorkel bundle 1 1000.00 1000.00", catalog)[0]
        self.assertIsNone(bundle["estimatedHours"])
        self.assertIn("multiple product codes", bundle["estimateSource"])

    def test_job_lines_merge_without_deleting_previous_email_work(self):
        previous = [{"id": "jobline-old", "description": "Existing tint", "estimatedHours": None}]
        incoming = [{"id": "jobline-new", "description": "New snorkel", "estimatedHours": 3.5}]
        merged = publisher.merge_vehicles(
            [{"stock": "13037843", "pdcJobLines": previous}],
            [{"stock": "13037843", "pdcJobLines": incoming}],
        )
        self.assertEqual({line["id"] for line in merged[0]["pdcJobLines"]}, {"jobline-old", "jobline-new"})

    def test_public_vehicle_removes_raw_mailbox_fields(self):
        sanitized = publisher.sanitize_public_vehicle({
            "stock": "13037843",
            "sourceRow": "Email intake",
            "source": "Email intake · mailbox@example.com",
            "notes": "raw email body",
            "sourceEmailSubject": "private subject",
            "sourceEmailSender": "sender@example.com",
        })
        self.assertNotIn("notes", sanitized)
        self.assertNotIn("sourceEmailSubject", sanitized)
        self.assertNotIn("sourceEmailSender", sanitized)
        self.assertEqual(sanitized["source"], "Email intake")
    def test_git_commit_is_scoped_to_generated_paths(self):
        output = publisher.ROOT / "email-board-data.js"
        with mock.patch.object(publisher, "run", side_effect=["", "M email-board-data.js", "", ""]) as run:
            self.assertTrue(publisher.git_commit_push("publish", [output]))
        commit_cmd = run.call_args_list[2].args[0]
        self.assertEqual(commit_cmd[:3], ["git", "commit", "--only"])
        self.assertEqual(commit_cmd[-2:], ["--", "email-board-data.js"])


if __name__ == "__main__":
    unittest.main()

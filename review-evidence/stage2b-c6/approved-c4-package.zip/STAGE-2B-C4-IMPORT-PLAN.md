# Stage 2B C4 — Import Plan

## Current gate

**NOT APPROVED FOR REAL IMPORT.** Readiness assessment found 18 conflicting, 0 ambiguous and 18 invalid vehicle records. C4 performs no import.

## Required dry-run preview

1. Resolve every row in the manual-review CSV and produce a signed-off resolution ledger.
2. Generate a fresh migration-031 typed reference artifact from the exact approved staging project identified by the existing guarded C3 configuration.
3. Run migration-029 preview only, in staging, against deterministic batches. Persist request IDs, source checksums, expected versions, actions and refusal reasons.
4. Re-run the same preview and require byte-identical actions and checksum before approval.

## Approval gates

- Gate A — data owner: manual conflicts, ambiguous links, placeholders and malformed identities resolved.
- Gate B — technical: deterministic preview, zero unresolved conflicts, exact project guard, credential scan and independent review pass.
- Gate C — explicit execution approval: a separate preview showing exact counts/actions/checksum and rollback revision. Approval expires if input, artifact revision, quote, environment or preview changes.
- No approval is implied by this document.

## Backup requirements

- Fresh encrypted backup immediately before any staging apply.
- Verify checksum, migration ledger and isolated-schema restore; then drop temporary schema/role.
- Record baseline counts for vehicles, identifiers, aliases, source evidence, history, audit, receipts and bookings.

## Manual conflict resolution

- Never choose a winner by row order or fuzzy matching.
- Resolve duplicate stock/VIN/job-card and cross-identifier ownership against the source system of record.
- Give every decision an owner, reason, date and immutable source-record reference.
- Invalid or unresolved records remain excluded; attached orphan data is never silently discarded.

## Staged batch sizes

- Pilot: 10 clean records.
- Verification batch: 25 clean records.
- Subsequent batches: maximum 50 clean records, reduced after any conflict or retry.
- Stop on any stale version, ambiguity, unexpected action, receipt mismatch or reconciliation variance.

## Rollback

- Staging/test only, disabled by default, explicit and revision-locked.
- Refuse stale artifacts/revisions. Export affected rows and receipts before rollback.
- After rollback, reconcile against backup baseline and require zero residue.

## Post-import reconciliation

- Re-export migration-031 references after each batch.
- Compare every source record to canonical UUID, matched claim type, expected/actual version, action and deterministic reason.
- Require exact receipt replay after simulated response loss and zero unresolved conflict/orphan drift.

## Browser-local fallback and authority cutover

Browser-local authority may remain a read-only fallback while any manual-review row, unmatched attachment, reconciliation variance, stale-version failure or rollback uncertainty remains. It must not be cleared.

Authority cutover may be proposed only after all approved batches reconcile exactly; zero unresolved conflicts/orphans remain; backup/restore and rollback are proven; a sustained read-only comparison window passes; browser-local fallback export is retained; and a separate reviewed approval explicitly authorizes cutover. C4 does not authorize cutover or direct-SELECT retirement.

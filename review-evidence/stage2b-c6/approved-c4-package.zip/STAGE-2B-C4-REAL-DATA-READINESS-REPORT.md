# Stage 2B C4 — Real-Data Readiness Report

## Scope and safety

- Assessment only; no import or upload was performed.
- Browser-local storage was read without mutation; before/after SHA-256 values matched.
- Supabase staging and production were not contacted.
- Export is narrow: customer details, note text, file contents, audit details and full Navision payloads are excluded.

## Vehicle readiness

| Measure | Count |
|---|---:|
| Total vehicles | 210 |
| Clean | 192 |
| Conflicting | 18 |
| Ambiguous | 0 |
| Invalid | 18 |
| Manual-review rows | 21 |
| Cannot match deterministically | 0 |

Issue counts may overlap: for example, a malformed VIN duplicated across records is both conflicting and invalid. `classification_counts` in the machine-readable summary provides the deterministic primary classification used by the CSV.

## Identity quality

| Measure | Count |
|---|---:|
| Duplicate normalized stock groups | 0 |
| Duplicate VIN groups | 3 |
| Duplicate job-card groups | 0 |
| Conflicting canonical-identifier findings | 6 |
| Placeholder stock records | 0 |
| Malformed VIN records | 18 |
| Missing stock | 0 |
| Missing VIN | 0 |
| Missing job card | 210 |
| Missing permanent vehicle ID | 210 |
| Missing Toyota order | 0 |

## Attached browser-local records

| Family | Orphan | Ambiguous link |
|---|---:|---:|
| Notes | 0 | 0 |
| Parts | 0 | 0 |
| Workflow | 3 | 0 |
| Bookings | 0 | 0 |

## Deterministic evidence

- Source assessment SHA-256: `7d862abbe37b5ccc42315195e8ab43bd6ee44f088fece4c33275f19e3c6e3661`
- Browser-local snapshot SHA-256: `ceed898872fe154728072ec264d60a3cd045696f355a436b1200c1fedf4edb62`
- Summary SHA-256: `4ec8ca6581adbed19b1bbe6c671fb94770777412bda4cebeb61325b7157b44ba`
- Parse errors: `0`

Every non-clean vehicle and every orphan/ambiguous attached record is listed in `STAGE-2B-C4-MANUAL-REVIEW-LIST.csv`. Duplicate values and record references are retained in the package's narrow `assessment-summary.json`; broad customer and operational payloads are not retained.
